package com.string;

public class StringConcat {
	public String concat(String s1, String s2) {
		String s = s1 + s2;
		return s;

	}
}
